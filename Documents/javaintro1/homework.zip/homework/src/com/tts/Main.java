package com.tts;

public class Main {

    public static void main(String[] args) {
        int size = 5;
        for (int i = 1; i <= size; i++) {
            for (int j = size; j >= 1; j--) {
                if (j > i)
                    System.out.print(" ");
                else
                    System.out.print("*");
            }
            System.out.println();
        }
    }
    // i followed along with a tutorial. I was having trouble trying to flip the print though.
}

//  int k = 80;
//  for(int i = 0; i < 5; i++) {
//  k = k - 12;
//  }
// the value of k after the loop executes is 0.